const Header=()=>{
    var ob={backgroundColor:"blue",color:"white",paddingLeft:"200px"};
   return (
    <h1 style={ob}>Name List For component Communication</h1>
   )
}
export default Header;